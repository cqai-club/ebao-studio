/** Host Loader entry; keyboard commands execute in the browser half. */
/** Register the browser package without adding Host behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map