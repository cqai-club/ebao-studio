/** Shared indeterminate loading feedback for document reads and rendering. */
import type { ReactNode } from 'react';
/**
 * @param props - localized status label and compact inline placement for additional pages.
 * @returns a centered document loading status or an accessible inline spinner.
 */
export declare function LoadingIndicator({ label, inline }: {
    label: string;
    inline?: boolean;
}): ReactNode;
//# sourceMappingURL=LoadingIndicator.d.ts.map