import type { Recording } from './audio.ts';
/** Render recent measured microphone levels; silent audio remains a dotted baseline. */
export declare function Waveform({ recording, label }: {
    readonly recording: Recording | undefined;
    readonly label: string;
}): import("react").JSX.Element;
//# sourceMappingURL=Waveform.d.ts.map