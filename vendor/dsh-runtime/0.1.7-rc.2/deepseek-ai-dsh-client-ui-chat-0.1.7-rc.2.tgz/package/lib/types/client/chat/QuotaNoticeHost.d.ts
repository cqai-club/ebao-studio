import type { QuotaNoticeHostProps } from '../contract/slots.ts';
/**
 * @param props - the live notice, its dismissal, the chain outlet, and the locale seat.
 * @returns the notice on display, or null while none is live.
 */
export declare function QuotaNoticeHost({ useNotice, dismissNotice, keepNoticeOpen, renderSlotChain, t }: QuotaNoticeHostProps): import("react").JSX.Element | null;
//# sourceMappingURL=QuotaNoticeHost.d.ts.map