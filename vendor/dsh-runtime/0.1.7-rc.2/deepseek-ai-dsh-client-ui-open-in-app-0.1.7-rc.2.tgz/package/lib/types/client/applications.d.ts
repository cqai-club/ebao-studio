/** Nameable application ids shared by the button and its keyboard command. */
import type { OpenInAppKey } from './locales.ts';
/** Label keys for applications supported by this client. */
export declare const APP_LABEL_KEY: Record<string, OpenInAppKey | undefined>;
//# sourceMappingURL=applications.d.ts.map