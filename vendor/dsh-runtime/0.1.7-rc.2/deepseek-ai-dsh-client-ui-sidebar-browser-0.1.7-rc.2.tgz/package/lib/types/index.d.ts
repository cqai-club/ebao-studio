/** Host companion for the Sidebar Browser Client plugin. */
/** Mount the browser-only plugin through the Client loader. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map