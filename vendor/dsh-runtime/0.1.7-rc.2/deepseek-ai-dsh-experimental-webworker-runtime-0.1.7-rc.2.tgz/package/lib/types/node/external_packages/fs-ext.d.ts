/**
 * Asynchronous flock face; the single-process worker grants every lock.
 * @param _fd - file descriptor (unused).
 * @param _flags - lock flags (unused).
 * @param callback - completion callback, invoked with no error.
 */
export declare function flock(_fd: number, _flags: unknown, callback: (error: null) => void): void;
/**
 * Synchronous flock face; the single-process worker grants every lock.
 */
export declare function flockSync(): void;
/** Unreached in the worker; loud refusal. */
export declare const fcntl: (...args: never[]) => never;
/** Unreached in the worker; loud refusal. */
export declare const fcntlSync: (...args: never[]) => never;
/** Unreached in the worker; loud refusal. */
export declare const seek: (...args: never[]) => never;
/** Unreached in the worker; loud refusal. */
export declare const seekSync: (...args: never[]) => never;
/** Unreached in the worker; loud refusal. */
export declare const statVFS: (...args: never[]) => never;
/** CommonJS interop marker: the worker loader hands `default` to default imports (see ./builtins.ts). */
export declare const __esModule = true;
/** The fs-ext face its consumers read. */
declare const _default: {
    flock: typeof flock;
    flockSync: typeof flockSync;
    fcntl: (...args: never[]) => never;
    fcntlSync: (...args: never[]) => never;
    seek: (...args: never[]) => never;
    seekSync: (...args: never[]) => never;
    statVFS: (...args: never[]) => never;
};
export default _default;
//# sourceMappingURL=fs-ext.d.ts.map