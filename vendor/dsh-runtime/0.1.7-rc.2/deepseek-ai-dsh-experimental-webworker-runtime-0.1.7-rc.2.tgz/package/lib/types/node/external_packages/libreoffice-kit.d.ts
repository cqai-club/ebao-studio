/**
 * Refuse converter creation with the kit's unavailable error code.
 * @returns A rejected promise consumed by the Host office-to-pdf provider.
 */
export declare function createConverter(): Promise<never>;
//# sourceMappingURL=libreoffice-kit.d.ts.map