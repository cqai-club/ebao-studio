/**
 * Render an image without introducing a second activation target.
 * @param props - Source, accessible description, localized status.
 * @returns A contained preview with loading or failure status.
 */
export declare function ImagePreview({ src, alt, loadingLabel, failedLabel }: {
    src: string;
    alt: string;
    loadingLabel: string;
    failedLabel: string;
}): import("react").JSX.Element;
//# sourceMappingURL=ImagePreview.d.ts.map