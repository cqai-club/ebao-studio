/** Fixed-palette artwork for sidebar guide entries. */
import type { IconProps } from './icons/props.ts';
/**
 * Render fixed-palette artwork for a sidebar guide entry.
 * @param props - canvas size and layout class supplied by the guide.
 * @returns an ornamental SVG hidden from assistive technology.
 */
export declare function GuideArtworkBrowser({ size, className }: IconProps): import("react").JSX.Element;
/**
 * Render fixed-palette artwork for a sidebar guide entry.
 * @param props - canvas size and layout class supplied by the guide.
 * @returns an ornamental SVG hidden from assistive technology.
 */
export declare function GuideArtworkFiles({ size, className }: IconProps): import("react").JSX.Element;
//# sourceMappingURL=guide-artwork.d.ts.map