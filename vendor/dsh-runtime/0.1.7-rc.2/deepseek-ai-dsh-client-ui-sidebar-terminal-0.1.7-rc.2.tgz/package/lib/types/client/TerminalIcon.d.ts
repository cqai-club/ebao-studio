/** Terminal glyph for sidebar tab titles. */
import type { ReactNode } from 'react';
/**
 * Render the tab title's terminal prompt in the surrounding text color.
 * @returns a decorative sixteen-pixel line glyph.
 */
export declare function TerminalIcon(): ReactNode;
//# sourceMappingURL=TerminalIcon.d.ts.map