declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        sidebarTerminal: keyof typeof zh;
    }
}
/** Simplified Chinese terminal copy. */
export declare const zh: {
    'shortcut.noSession': string;
    recoveryFailed: string;
    retryRecovery: string;
    shell: string;
    shellLoading: string;
    shellEmpty: string;
    description: string;
    title: string;
    new: string;
    loading: string;
    creating: string;
    connecting: string;
    disconnected: string;
    reconnect: string;
    readonly: string;
    control: string;
    closed: string;
    exited: string;
    failed: string;
    rename: string;
    unavailable: string;
    retry: string;
    cleanupFailed: string;
    missingTerminal: string;
    inputFull: string;
    attachmentEnded: string;
    invalidOutput: string;
    terminalLimit: string;
};
/** English terminal copy. */
export declare const en: {
    'shortcut.noSession': string;
    recoveryFailed: string;
    retryRecovery: string;
    shell: string;
    shellLoading: string;
    shellEmpty: string;
    description: string;
    title: string;
    new: string;
    loading: string;
    creating: string;
    connecting: string;
    disconnected: string;
    reconnect: string;
    readonly: string;
    control: string;
    closed: string;
    exited: string;
    failed: string;
    rename: string;
    unavailable: string;
    retry: string;
    cleanupFailed: string;
    missingTerminal: string;
    inputFull: string;
    attachmentEnded: string;
    invalidOutput: string;
    terminalLimit: string;
};
//# sourceMappingURL=locales.d.ts.map