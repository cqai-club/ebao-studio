import type { DesktopOnboardingProps } from './onboarding-contract.ts';
/**
 * @param props - durable choices, account state, localized copy and the shared recharge page channel.
 * @returns the active first-run page.
 */
export declare function DesktopOnboarding({ state, account, openPlatformPage, update, complete, retry, t, locale, exiting, }: DesktopOnboardingProps): import("react").JSX.Element | null;
//# sourceMappingURL=DesktopOnboarding.d.ts.map