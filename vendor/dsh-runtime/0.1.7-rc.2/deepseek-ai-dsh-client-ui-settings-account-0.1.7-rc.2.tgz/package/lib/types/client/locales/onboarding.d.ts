/** Chinese first-run copy from the onboarding requirements. */
export declare const onboardingCopy: {
    readonly onboardingArtworkLocale: "zh";
    readonly onboardingWelcome: "欢迎使用";
    readonly onboardingBrand: "DeepSeek Harness";
    readonly onboardingIntroduction: "DeepSeek Harness 会以本地文件夹作为工作区，通过调用各种工具，读写本机文件，完成搜索整理资料、制作文档表格、编写代码、排查问题等各种任务。";
    readonly onboardingStart: "开始设置";
    readonly onboardingCredit: "准备可用额度";
    readonly onboardingCreditDescription: "DeepSeek Harness 执行任务时，会根据模型与工具使用的 token 量扣除额度。请提前添加额度，避免任务在执行过程中被迫中断。你的余额只会在 Agent 实际执行任务时消耗。";
    readonly onboardingTopUp: "去充值";
    readonly onboardingLater: "下一步";
    readonly onboardingFundedTopUp: "去充值";
    readonly onboardingPurposePrefix: "你希望";
    readonly onboardingPurposeSuffix: "帮你做什么？";
    readonly onboardingPurposeDescription: "我们会根据你的选择调整界面和工具，以更适合你的工作方式。";
    readonly onboardingOffice: "办公与创作";
    readonly onboardingOfficeDescription: "编辑文档、整理数据和制作演示文稿等";
    readonly onboardingDevelopment: "代码与开发";
    readonly onboardingDevelopmentDescription: "修改代码、调试问题、运行命令和管理项目文件等";
    readonly onboardingContinue: "继续";
    readonly onboardingProcess: "你希望看到多少工作过程？";
    readonly onboardingProcessDescription: "这只会影响工作过程的展示方式，不会影响 DeepSeek Harness 的工作能力。";
    readonly onboardingCompact: "聚焦结果";
    readonly onboardingCompactDescription: "只看结果，保持界面简洁明了";
    readonly onboardingStandard: "关键细节";
    readonly onboardingStandardDescription: "结果优先，仅展示重要步骤和关键操作";
    readonly onboardingDetailed: "完整过程";
    readonly onboardingDetailedDescription: "查看完整工作过程，方便调试和排查问题";
    readonly onboardingEnter: "进入应用";
    readonly onboardingBack: "上一步";
    readonly onboardingSkip: "跳过";
    readonly onboardingSkipTitle: "跳过设置？";
    readonly onboardingSkipDescription: "你可以随时前往 个人中心 → 通用设置 中调整工作过程、性能与用量展示方式或开启代码工作工具。";
    readonly onboardingKeepSetting: "继续设置";
    readonly onboardingNoCreditTitle: "暂时跳过充值？";
    readonly onboardingNoCreditDescription: "没有可用额度时，DeepSeek Harness 将无法开始新的任务。你可以稍后前往 个人中心 → 账号与余额 进行充值。";
    readonly onboardingUnderstood: "我知道了";
    readonly onboardingGoTopUp: "前往充值";
    readonly onboardingSaveFailed: "未能保存设置，请重试。";
    readonly onboardingRetry: "重试";
    readonly onboardingLoading: "正在加载设置…";
};
/** English first-run copy with the same keys as the Chinese dictionary. */
export declare const onboardingEnglishCopy: Record<keyof typeof onboardingCopy, string>;
//# sourceMappingURL=onboarding.d.ts.map