/** Feishu questionnaire context follows the Platform Web ticket fields. */
import type { ContactConfig } from '../contact-config.ts';
/**
 * Build an external questionnaire URL without authentication credentials.
 * @param config - questionnaire destination and supported source option.
 * @param context - currently available build and browser environment.
 * @returns questionnaire URL with hidden, optionally prefilled context fields.
 */
export declare function contactUrl(config: ContactConfig, context: {
    version: string | undefined;
    locale: string;
    width: number;
    height: number;
    pixelRatio: number;
}): string;
//# sourceMappingURL=contact-url.d.ts.map