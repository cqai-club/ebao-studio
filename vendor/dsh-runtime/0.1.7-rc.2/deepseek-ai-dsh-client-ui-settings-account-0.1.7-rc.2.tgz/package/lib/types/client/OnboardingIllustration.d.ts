/** @param props - artwork URLs and feature-owned geometry. @returns decorative theme variants. */
export declare function OnboardingIllustration({ className, src, darkSrc }: {
    className?: string | undefined;
    src: string;
    darkSrc: string;
}): import("react").JSX.Element;
//# sourceMappingURL=OnboardingIllustration.d.ts.map