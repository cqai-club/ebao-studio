/** Desktop login owns model-credential discovery for both welcome and onboarding. */
/**
 * Read the same safe credential fact used by native login.
 * @returns configured API-key presence; rejects when the desktop bridge is unavailable.
 */
export declare function readOnboardingApiKeyPresence(): Promise<boolean>;
//# sourceMappingURL=onboarding-credentials.d.ts.map