/** Layout command labels. */
export declare const zh: {
    toggle: string;
};
/** English labels for the same layout commands. */
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=shortcut-locales.d.ts.map