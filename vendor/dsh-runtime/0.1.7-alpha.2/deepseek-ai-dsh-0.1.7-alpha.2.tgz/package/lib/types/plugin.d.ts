/** Run package management for a profile.
 * @param profile Profile name.
 * @param args Pnpm arguments relative to the invoking directory.
 * @returns Pnpm exit code.
 */
export declare function runPlugin(profile: string, args: readonly string[]): Promise<number>;
//# sourceMappingURL=plugin.d.ts.map