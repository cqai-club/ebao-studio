/** Account settings copy, owned by the account feature. */
export declare const en: {
    readonly close: "Close";
    readonly addApiKey: "Add API Key";
    readonly retry: "Sign in again";
    readonly loginTitle: "Start creating";
    readonly loginDescription: "Sign in to create, edit, and share your design projects. Everything is saved locally.";
    readonly browserTitle: "Waiting for sign in";
    readonly browserPrompt: "Page did not open automatically? ";
    readonly copyLink: "Copy sign-in link";
    readonly copiedLink: "Link copied";
    readonly copyFailed: "Copy failed";
    readonly browserDescription: ", then open it in your browser to finish signing in.";
    readonly timeoutTitle: "Sign in timed out";
    readonly timeoutDescription: "Sign in again to continue.";
    readonly failureTitle: "Could not sign in";
    readonly platformFailed: "Could not complete the operation. Try again.";
    readonly platformRetry: "Retry";
    readonly loading: "Loading…";
    readonly backToHarness: "Back to DeepSeek Harness";
    readonly settings: "Settings";
    readonly contactUs: "Feedback";
    readonly menu: "Account menu";
    readonly nav: "Account";
    readonly signedIn: "Signed in to DeepSeek";
    readonly signedOut: "Not signed in";
    readonly signIn: "Sign in";
    readonly signOut: "Sign out";
    readonly cancel: "Cancel";
    readonly open: "Open browser";
    readonly initializing: "Starting sign in…";
    readonly waiting: "Continue in your browser";
    readonly completing: "Completing sign in…";
    readonly expired: "Sign in expired. Try again.";
    readonly failed: "Could not complete the operation. Try again.";
    readonly settingsSignedOutTitle: "You are not signed in to DeepSeek Harness";
    readonly settingsSignedOutDescription: "Sign in to DeepSeek Harness to get your dedicated API Key";
    readonly signInDescription: "Use your DeepSeek account to get started.";
    readonly profileUnavailable: "Account details are not available yet.";
    readonly balance: "Recharge balance";
    readonly bonusBalance: "Bonus balance";
    readonly balanceUnavailable: "View on Platform";
    readonly balanceSignedOut: "Sign in to view";
    readonly accountInfo: "More account information";
    readonly more: "More";
    readonly usage: "View usage";
    readonly topUp: "Top up";
};
/** Account locale keys. */
export type AccountKey = keyof typeof en;
/** Chinese account settings copy. */
export declare const zh: Record<AccountKey, string>;
//# sourceMappingURL=locales.d.ts.map