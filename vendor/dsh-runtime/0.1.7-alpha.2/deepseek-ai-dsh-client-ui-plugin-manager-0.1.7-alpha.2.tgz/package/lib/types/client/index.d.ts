/**
 * Plugin manager, browser half: the **Plugins** entry of the sidebar and the
 * management page it opens in the main column. The page installs, enables,
 * disables, and removes the bundles of the Host's profile through the
 * `pluginManager` Remote and switches their rows in the profile's user layer.
 * A plugin that carries its own configuration renders it on this page through
 * the slots the page declares (`slot-contract.ts`).
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client';
import { type PluginManagerLocaleKey } from './locales.ts';
export type { PluginManagerPageProps } from './PluginManagerPage.tsx';
export type { ConfigLedger, OfficialItem } from './config-ledger.ts';
export type { PluginManagerFace } from './manager-store.ts';
export type { PluginManagerLocaleKey } from './locales.ts';
export type { ConfigPageForm, PluginActivationOwnerProps, PluginConfigViewProps, PluginDetailProps, PluginPackageRef, PluginRowRef, PluginsSubject, } from './slot-contract.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Plugin manager tab copy. */
        'pluginManager': PluginManagerLocaleKey;
    }
}
/** Dictionary namespace owned by this plugin. */
export declare const NS = "pluginManager";
/** The id shared by the sidebar entry and the main panel it opens. */
export declare const PANEL_ID: MainPanelId;
/** Services required by the sidebar registration and the Remote methods; the inventory says whether the Host manages a profile. */
export declare const inject: string[];
/**
 * Contribute the Plugins entry to the sidebar with the management page it
 * opens, and keep it current on the Host's change events.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map