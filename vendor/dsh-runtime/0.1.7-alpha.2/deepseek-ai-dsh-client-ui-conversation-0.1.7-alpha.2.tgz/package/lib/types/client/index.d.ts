/** Browser Conversation assemble core, React adapter, shell, and input plugin. */
export { apply, Config, inject } from './apply.ts';
export type { Config as ConversationConfig } from './apply.ts';
export { UiConversation } from './conversation/assembly.ts';
export type { ConversationBinding } from './conversation/assembly.ts';
export type { ConversationGroupRegistry } from './conversation/group-registry.ts';
export type { ConversationGroupContext, ConversationGroupData, ConversationGroupDataMap, ConversationGroupDefinition, ConversationGroupedView, ConversationGroupInput, GroupKey, GroupNodePosition, GroupReference, GroupSnapshot, GroupUpdate, NodeChange, NodeKey, NodeReference, RenderEntry, } from './contract/groups.ts';
export { ConversationController, UnsupportedImageMediaTypeError } from './service.ts';
export type { IConversation } from './service.ts';
export type { ConversationContextReader, ConversationLocation, ConversationLocationData, ConversationLocationDataScope, ConversationLocationDataSource, ConversationLocationDataStore, ConversationMatch, ConversationMatchResult, ConversationNodeContext, ConversationNodeDefinition, ConversationPreviousContext, ConversationPublication, ConversationStartMatch, ConversationStepDataMap, ConversationTimelineSnapshot, ConversationTurnDataMap, ConversationViewBuilder, ConversationViewDefinition, ConversationViewNode, ConversationViewSnapshotMap, ConversationViewSnapshotStore, StepLocation, TurnLocation, } from './contract/conversation.ts';
export { EMPTY_CONVERSATION_SNAPSHOT, conversationPhase } from './contract/snapshot.ts';
export type { ConversationPhase, ConversationSnapshot, } from './contract/snapshot.ts';
export type { AssistantBlock, AssistantMessageNode, AssistantProviderMetadataView, AssistantRequestConfig, AssistantTiming, CommandNode, CompactionSummaryNode, ContextMessageNode, ConversationNode, ModelRetryNode, PartialAssistant, RunningToolCall, SteeringMessageNode, TodoItem, ToolCallBlock, ToolResultNode, TurnErrorNode, TurnMaxTokensNode, UnknownSurfaceNode, UserMessageNode, } from './contract/records.ts';
export type { ContextProducerView, ContextRole, KnownContextForm, } from './contract/context-producer.ts';
export type { ConversationPromptSnapshot, RequestInspectionSnapshot, RequestPromptChange, RequestPromptInspection, RequestPromptInspector, RequestView, SystemPromptNode, } from './contract/request-inspection.ts';
export { inspectRequestPrompt } from './contract/request-inspection.ts';
export type { SystemPromptState, SystemPromptInspector } from './contract/system-prompt.ts';
export type { ConversationStoreState, ConversationViewRequest, ViewTab } from './contract/views.ts';
export { ConversationNodeAssembler } from './conversation/assembler.ts';
export type { ConversationEventDefinitions, ConversationGroupDefinitions, ConversationViewDefinitions, } from './conversation/assembler.ts';
export { ConversationDefinitionRegistry } from './conversation/definition-registry.ts';
export { ConversationEventRegistry } from './conversation/event-registry.ts';
export { ConversationLocationIndex } from './conversation/location-index.ts';
export type { ConversationLocationDataChange } from './conversation/location-index.ts';
export { ConversationViewRegistry } from './conversation/view-registry.ts';
export type { ConversationKey } from './locales.ts';
export type { ComposerAttachment, ComposerAttachmentsOwnerProps, ComposerAttachmentsProps, ComposerFileAttachment, ComposerImageAttachment, DraftFileUpload, DraftFileUploads, ComposerBarInjected, ComposerBarOwnerProps, ComposerBarProps, ComposerChainProps, ConversationHeaderActionOwnerProps, ConversationHeaderCornerOwnerProps, ConversationHeaderLineageOwnerProps, ConversationContentInputProps, ConversationContentProps, ConversationInjected, ConversationSessionHeaderInjected, ConversationSessionHeaderSlotProps, ConversationSessionInjected, ConversationSessionSlotProps, ConversationSlotProps, ConversationViewsProps, ConversationWidthControlsInputProps, ConversationWidthControlsProps, ConversationStore, ConvViewOwnerProps, ConvViewProps, EmptyWorkspaceOwnerProps, HeroAgentPresetOwnerProps, HeroBrandMarkOwnerProps, InputControlOwnerProps, InputZone, MessageImageLoader, MessageImageSource, MessageImagesOwnerProps, RenderMessageImages, UseConversation, UseConversationViews, } from './contract/slots.ts';
export type { BeginCommandRequest, CommandClaim, ConsumeTokenRequest, DraftAttachmentId, InputActions, InputState, InsertReferenceRequest, InsertTextRequest, PickOutcome, SessionInput, SessionInputResolver, SubmitAttachment, SubmitOutcome, } from './contract/input.ts';
export type { ArbitrateKey, ArbitrateOutcome, ReferenceInsert, TokenSpan } from './contract/draft-editor.ts';
export type { ComposerBlock, ComposerBlocks } from './contract/composer-blocks.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Scope-addressed Conversation actions and per-Session input registry. */
        conversation: import('./service.ts').IConversation;
        /** Target-neutral Conversation registries and per-Session assembly. */
        uiConversation: import('./conversation/assembly.ts').UiConversation;
    }
}
//# sourceMappingURL=index.d.ts.map