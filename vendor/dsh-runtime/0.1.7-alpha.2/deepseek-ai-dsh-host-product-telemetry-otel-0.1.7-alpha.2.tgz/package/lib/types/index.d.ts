/** Explicit product usage events over OTLP/HTTP; no automatic collection or Session access. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { SeverityNumber } from '@opentelemetry/api-logs';
declare module '@deepseek-ai/cordis' {
    interface Context {
        productTelemetry: ProductTelemetry;
    }
}
/** Scalar values accepted by the collector's Arrow attributes map. */
export type ProductTelemetryScalar = string | number | boolean;
/** Explicitly selected analytics fields; object values may contain scalars only. */
export interface ProductTelemetryRecord {
    /** Product/DA-owned event name. */
    eventName: string;
    /** Human-readable summary; never a prompt, response, credential, or file contents. */
    body: string;
    /** Event occurrence time in Unix milliseconds. Observation time is assigned on enqueue. */
    timestamp: number;
    /** OTel severity; omitted values use INFO. */
    severityNumber?: SeverityNumber;
    /** Business fields selected by the caller; no automatic device or account identity. */
    attributes?: Record<string, ProductTelemetryScalar | Record<string, ProductTelemetryScalar>>;
}
/** Collector routing, application identity, and bounded in-memory batch settings. */
export interface Config {
    /** Full HTTP(S) logs URL. */
    endpoint: string;
    /** Collector routing header. */
    channel: string;
    /** Resource service.name supplied by the application composition. */
    serviceName: string;
    /** Resource service.version supplied by the application composition. */
    serviceVersion: string;
    /** Omit to honor OTEL_EXPORTER_OTLP_LOGS_COMPRESSION / OTEL_EXPORTER_OTLP_COMPRESSION. */
    compression?: 'none' | 'gzip';
    /** Maximum records per export; must not exceed maxQueueSize. */
    maxExportBatchSize: number;
    /** Maximum queued records; the SDK drops new records when full. */
    maxQueueSize: number;
    /** Delay before exporting a partial batch. */
    scheduledDelayMillis: number;
    /** Exporter HTTP deadline, including SDK transient-error retries. */
    timeoutMillis: number;
    /** Processor deadline for one batch export. */
    exportTimeoutMillis: number;
    /** Outer shutdown wait; pending exports may be lost after this deadline. */
    shutdownTimeoutMillis: number;
}
/** Loader validation and defaults for application compositions. */
export declare const Config: z<Partial<Config>, Config>;
/** Host analytics sender. Mounting alone sends nothing; the owning fiber drains it on unload. */
export default class ProductTelemetry extends Service {
    static Config: z<Partial<Config>, Config>;
    private readonly logger;
    constructor(ctx: Context, config: Config);
    /**
     * Enqueue one selected product event without waiting for network delivery.
     * Queue admission and shutdown completion are not collector or warehouse acknowledgements.
     * @param record - caller-owned event containing only approved analytics fields.
     */
    emit(record: ProductTelemetryRecord): void;
}
//# sourceMappingURL=index.d.ts.map