/** Read-only text viewer the page shows when the worker's `xdg-open` names a VFS file. */
/**
 * Show one file in the page's modal viewer, replacing any file it already shows.
 * @param path - Absolute VFS path used as the title.
 * @param text - File contents, rendered as plain text.
 */
export declare function showTextViewer(path: string, text: string): void;
//# sourceMappingURL=text-viewer.d.ts.map