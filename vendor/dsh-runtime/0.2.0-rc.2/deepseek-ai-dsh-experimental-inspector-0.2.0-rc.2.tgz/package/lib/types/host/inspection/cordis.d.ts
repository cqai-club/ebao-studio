/** Host entry for the shared Cordis snapshot publisher. */
export { publishCordisTree } from '../../shared/cordis/publisher.ts';
//# sourceMappingURL=cordis.d.ts.map