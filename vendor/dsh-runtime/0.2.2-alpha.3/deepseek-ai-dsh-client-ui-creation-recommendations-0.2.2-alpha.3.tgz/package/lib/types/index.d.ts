/** Browser registration is discovered through the package client declaration. */
/** Register the browser-only contribution without Host state. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map