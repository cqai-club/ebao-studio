/** English creation and recovery copy. */
export declare const en: {
    heading: string;
    location: string;
    creationInfo: string;
    creationMethod: string;
    creationCost: string;
    creationBackground: string;
    initialContent: string;
    expandContent: string;
    collapseContent: string;
    'sidebar-right': string;
    page: string;
    'sidebar-left': string;
    custom: string;
    'sidebar-rightHint': string;
    pageHint: string;
    'sidebar-leftHint': string;
    customHint: string;
    customLabel: string;
    customPlaceholder: string;
    create: string;
    starting: string;
    dismiss: string;
    retry: string;
    undo: string;
    restore: string;
    restoring: string;
    dismissed: string;
    replaced: string;
    creating: string;
    cancel: string;
    cancelling: string;
    installing: string;
    sourceRetained: string;
    installed: string;
    kept: string;
    removed: string;
    failed: string;
    interrupted: string;
    unconfirmed: string;
    'invalid-location': string;
    'restart-required': string;
    overridden: string;
    cancelled: string;
    applicationFailed: string;
    applicationCancelled: string;
    transport: string;
    unknown: string;
    unavailable: string;
    'access-denied': string;
    'not-live-root': string;
    closing: string;
    'read-only': string;
    'source-missing': string;
};
/** Keys shared by both dictionaries. */
export type RecommendationKey = keyof typeof en;
/** Chinese creation and recovery copy. */
export declare const zh: Record<RecommendationKey, string>;
/** Japanese creation and recovery copy. */
export declare const ja: Record<RecommendationKey, string>;
/** Spanish creation and recovery copy. */
export declare const es: Record<RecommendationKey, string>;
/** French creation and recovery copy. */
export declare const fr: Record<RecommendationKey, string>;
/** German creation and recovery copy. */
export declare const de: Record<RecommendationKey, string>;
/** Russian creation and recovery copy. */
export declare const ru: Record<RecommendationKey, string>;
/** Portuguese creation and recovery copy. */
export declare const pt: Record<RecommendationKey, string>;
//# sourceMappingURL=locales.d.ts.map