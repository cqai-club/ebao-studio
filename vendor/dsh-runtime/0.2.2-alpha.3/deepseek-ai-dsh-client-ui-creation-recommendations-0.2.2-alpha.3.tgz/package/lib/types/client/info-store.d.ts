import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
/** Remember the dismissed creation notice across sessions in this browser.
 * @returns a plugin-owned preference; unavailable storage only disables persistence.
 */
export declare function createCreationInfoStore(): SnapshotStore<boolean>;
//# sourceMappingURL=info-store.d.ts.map