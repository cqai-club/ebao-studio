/** Centered review submission with a summary, decision, and pending-comment count. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ReviewQueue } from './review-queue.ts';
import type { NS } from './locales.ts';
/**
 * Submit a review independently of the diff scroll position; comments remain at their code locations.
 * @param props - durable queue, current head, submission outcome, and modal actions.
 * @returns a portalled modal with keyboard focus ownership.
 */
export declare function SubmitReview({ queue, url, headSha, busy, error, submit, close, check, reconcile, t }: PropsLocale<typeof NS> & {
    readonly queue: ReviewQueue;
    readonly url: string;
    readonly headSha: string;
    readonly busy: boolean;
    readonly error: string | null;
    readonly submit: () => void;
    readonly close: () => void;
    readonly check: () => void;
    readonly reconcile: () => void;
}): ReactNode;
//# sourceMappingURL=SubmitReview.d.ts.map