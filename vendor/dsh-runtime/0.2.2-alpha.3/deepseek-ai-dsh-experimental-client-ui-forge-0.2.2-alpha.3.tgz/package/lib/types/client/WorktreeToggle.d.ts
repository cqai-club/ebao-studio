/** New Session option: start the Session in a new worktree, from a chosen local branch. */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeBranches } from '../types.ts';
import type { NS } from './locales.ts';
import type { PanelSnapshot } from './source.ts';
/** Business face of the New Session option. */
export interface WorktreeToggleInjected {
    /** Panel snapshot of the Session; the renderer binds it as `usePanel`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
    };
    /**
     * Request a worktree from a base branch, replacing an open request.
     * @param from - base branch, or null for HEAD.
     * @returns whether the Host accepted it.
     */
    readonly request: (from: string | null) => Promise<boolean>;
    /**
     * Withdraw the open request.
     * @returns whether the Host accepted it.
     */
    readonly cancel: () => Promise<boolean>;
    /**
     * List the local branches of the Session's checkout.
     * @returns the branches, or undefined when they could not be read.
     */
    readonly branches: () => Promise<ForgeBranches | undefined>;
}
/** Full props of the New Session option. */
export type WorktreeToggleProps = InjectFace<WorktreeToggleInjected> & PropsLocale<typeof NS>;
/**
 * Render the worktree option while the Session can still start in a worktree:
 * the current branch, or the base branch menu once requested, then the checkbox.
 * A blocked request keeps its selected base visible without a menu; the checkbox
 * only withdraws it. Branch details support pointer, touch, and keyboard access.
 * The request stays fixed while the worktree is being created.
 * @param props - panel snapshot hook, request actions, and copy.
 * @returns the option, or nothing outside a known Git checkout, once a turn started,
 * the request settled, or no worktree service is mounted.
 */
export declare function WorktreeToggle({ usePanel, request, cancel, branches, t }: WorktreeToggleProps): ReactNode;
//# sourceMappingURL=WorktreeToggle.d.ts.map