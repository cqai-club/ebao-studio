/**
 * The panel card of the checkout's `branch` scope changes, independent of
 * change request bindings: file counts and paths open the local changes view,
 * and an optional action asks the Agent for a change request.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeLocalChanges } from '../types.ts';
import type { NS } from './locales.ts';
/** Props of the local changes card. */
export interface LocalChangesCardProps {
    /** Files the `branch` scope changes and the ref it compares with. */
    readonly local: ForgeLocalChanges;
    /** Whether the card offers to create a change request. */
    readonly creatable: boolean;
    /** Open the changes view, scrolled to `path` when given. */
    readonly view: (path?: string) => void;
    /** Ask the Agent to create a change request for the changes. */
    readonly create: () => void;
    /** Forge panel copy. */
    readonly t: PropsLocale<typeof NS>['t'];
}
/**
 * Render the local changes card; the file list starts collapsed.
 * @param props - the changes, the view and create actions, and copy.
 * @returns the card.
 */
export declare function LocalChangesCard({ local, creatable, view, create, t }: LocalChangesCardProps): ReactNode;
//# sourceMappingURL=LocalChangesCard.d.ts.map