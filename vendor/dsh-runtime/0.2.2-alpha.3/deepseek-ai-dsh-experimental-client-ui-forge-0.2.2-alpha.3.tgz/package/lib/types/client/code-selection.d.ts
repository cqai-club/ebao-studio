/** Read browser text selections from one diff side without including the interleaved opposite column. */
/** Selected displayed lines and the exact selected text on their side. */
export interface CodeSelection {
    readonly side: 'L' | 'R';
    readonly from: number;
    readonly to: number;
    readonly text: string;
}
/**
 * Find the side where a text selection begins; unified context belongs to the new side.
 * @param root - this file's diff element.
 * @param node - pointer or selection anchor.
 * @returns the available side, or undefined outside code text.
 */
export declare function codeSideAt(root: HTMLElement, node: Node | null): 'L' | 'R' | undefined;
/**
 * Read only code fragments from the selected side, retaining partial first and last lines for copy.
 * @param root - this file's diff element.
 * @param side - side captured when the gesture began.
 * @returns the selected range and text, or undefined for collapsed or cross-file selections.
 */
export declare function readCodeSelection(root: HTMLElement, side: 'L' | 'R'): CodeSelection | undefined;
//# sourceMappingURL=code-selection.d.ts.map