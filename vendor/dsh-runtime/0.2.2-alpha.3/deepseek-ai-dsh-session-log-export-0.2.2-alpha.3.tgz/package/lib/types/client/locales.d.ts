/** Locale namespace owned by Session export browser feedback. */
export declare const NS = "session-log-download";
/** Simplified-Chinese Session export strings. */
export declare const zh: {
    readonly 'header.more': "更多操作";
    readonly 'menu.copyMarkdown': "复制会话为 Markdown";
    readonly 'menu.download': "下载 Session 日志";
    readonly 'menu.feedback': "反馈";
    readonly 'toast.copied': "Session 已复制为 Markdown";
    readonly 'toast.preparationFailed': "无法读取 Session 进行复制，请重试";
    readonly 'toast.clipboardFailed': "无法写入剪贴板，请检查剪贴板权限后重试";
    readonly 'dialog.preparingTitle': "正在导出 Session";
    readonly 'dialog.preparingDescription': "正在准备包含当前 Session、子 Session 和附件的 ZIP 文件。";
    readonly 'dialog.successTitle': "Session 导出已开始下载";
    readonly 'dialog.successDescription': "浏览器正在下载 Session ZIP 文件。";
    readonly 'dialog.errorTitle': "Session 导出失败";
    readonly 'dialog.close': "关闭";
    readonly 'dialog.commandFailed': "无法启动 Session 导出。";
};
/** English Session export strings. */
export declare const en: Record<keyof typeof zh, string>;
/** Stable locale keys consumed by the shared modal. */
export type SessionLogDownloadKey = keyof typeof zh;
/** Japanese copy, checked against the English keys. */
export declare const ja: {
    'header.more': string;
    'menu.copyMarkdown': string;
    'menu.download': string;
    'menu.feedback': string;
    'toast.copied': string;
    'toast.preparationFailed': string;
    'toast.clipboardFailed': string;
    'dialog.preparingTitle': string;
    'dialog.preparingDescription': string;
    'dialog.successTitle': string;
    'dialog.successDescription': string;
    'dialog.errorTitle': string;
    'dialog.close': string;
    'dialog.commandFailed': string;
};
/** Spanish dictionary, checked against the English keys. */
export declare const es: {
    'header.more': string;
    'menu.copyMarkdown': string;
    'menu.download': string;
    'menu.feedback': string;
    'toast.copied': string;
    'toast.preparationFailed': string;
    'toast.clipboardFailed': string;
    'dialog.preparingTitle': string;
    'dialog.preparingDescription': string;
    'dialog.successTitle': string;
    'dialog.successDescription': string;
    'dialog.errorTitle': string;
    'dialog.close': string;
    'dialog.commandFailed': string;
};
/** French dictionary, checked against the English keys. */
export declare const fr: {
    'header.more': string;
    'menu.copyMarkdown': string;
    'menu.download': string;
    'menu.feedback': string;
    'toast.copied': string;
    'toast.preparationFailed': string;
    'toast.clipboardFailed': string;
    'dialog.preparingTitle': string;
    'dialog.preparingDescription': string;
    'dialog.successTitle': string;
    'dialog.successDescription': string;
    'dialog.errorTitle': string;
    'dialog.close': string;
    'dialog.commandFailed': string;
};
/** German dictionary, checked against the English keys. */
export declare const de: {
    'header.more': string;
    'menu.copyMarkdown': string;
    'menu.download': string;
    'menu.feedback': string;
    'toast.copied': string;
    'toast.preparationFailed': string;
    'toast.clipboardFailed': string;
    'dialog.preparingTitle': string;
    'dialog.preparingDescription': string;
    'dialog.successTitle': string;
    'dialog.successDescription': string;
    'dialog.errorTitle': string;
    'dialog.close': string;
    'dialog.commandFailed': string;
};
/** Russian dictionary, checked against the English keys. */
export declare const ru: {
    'header.more': string;
    'menu.copyMarkdown': string;
    'menu.download': string;
    'menu.feedback': string;
    'toast.copied': string;
    'toast.preparationFailed': string;
    'toast.clipboardFailed': string;
    'dialog.preparingTitle': string;
    'dialog.preparingDescription': string;
    'dialog.successTitle': string;
    'dialog.successDescription': string;
    'dialog.errorTitle': string;
    'dialog.close': string;
    'dialog.commandFailed': string;
};
/** Portuguese dictionary, checked against the English keys. */
export declare const pt: {
    'header.more': string;
    'menu.copyMarkdown': string;
    'menu.download': string;
    'menu.feedback': string;
    'toast.copied': string;
    'toast.preparationFailed': string;
    'toast.clipboardFailed': string;
    'dialog.preparingTitle': string;
    'dialog.preparingDescription': string;
    'dialog.successTitle': string;
    'dialog.successDescription': string;
    'dialog.errorTitle': string;
    'dialog.close': string;
    'dialog.commandFailed': string;
};
//# sourceMappingURL=locales.d.ts.map