/**
 * Register the DeepSeek Search and Fetch APIs in `ctx.web` as `deepseek-search-api`
 * and `deepseek-fetch-api`. Each operation is one direct API request without an
 * auxiliary model request. `web.searchProvider` and `web.fetchProvider` select them. Each capability follows the
 * DeepSeek credential of the conversation: a Session whose latest model request used the `deepseek-account` route sends
 * the account token to that route's origin, and every other operation sends the API key of the DeepSeek API-key route
 * to that route's origin, or `DEEPSEEK_API_KEY` to the official base without that route. An operation that needs a
 * mounted route whose settings do not resolve fails instead of changing its endpoint or credential. A capability with
 * its own `*BaseURL` or `*ApiKeyEnv` uses only that endpoint and key instead
 * ([rationale](../../../../.agents/notes/implemented/architecture/2026-10-29-web-provider-selection.md#credential-resolution)).
 * Both providers report themselves not ready when their next operation would have no credential.
 * @module @deepseek-ai/dsh-web-deepseek-api
 */
import { type Context, type Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { DEEPSEEK_FETCH_API_PROVIDER_ID, DeepSeekFetchApiProvider } from './fetch.ts';
export type { DeepSeekFetchApiOptions } from './fetch.ts';
export { DEEPSEEK_DEFAULT_COUNT, DEEPSEEK_SEARCH_API_PROVIDER_ID, DEEPSEEK_SEARCH_REQUESTS_PER_SECOND, DEEPSEEK_WEB_API_BASE_URL, DeepSeekSearchApiProvider, mapSearchResponse, } from './search.ts';
export type { DeepSeekSearchApiOptions } from './search.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "web-deepseek-api";
/** The web seam both providers register into. */
export declare const inject: string[];
/**
 * Settings read by the next search or fetch without re-registering either provider. A non-empty `*BaseURL` or
 * `*ApiKeyEnv` gives that capability its own endpoint and key; with neither, it follows the conversation's DeepSeek
 * credential. Stored fields of earlier settings (`baseURL`, `apiKeyEnv`, `apiKey`) are not schema fields: they load
 * without error and have no effect.
 */
export interface Config {
    /** Search API results per search, from 1 through 50; a smaller request bound wins. Defaults to 10. */
    count: Volatile<number>;
    /**
     * Most Search requests this plugin instance sends in any one-second window; later searches wait,
     * and the wait counts against the caller's timeout. Other processes and clients on the same account
     * share the account limit without coordination. Defaults to 5.
     */
    searchRequestsPerSecond: Volatile<number>;
    /** Send the triggering user question, bounded to 128 characters, as `ori_question`. Defaults to true. */
    sendOriginalQuestion: Volatile<boolean>;
    /**
     * Own Search API base including its path prefix; `/search` is appended. With only {@link searchApiKeyEnv} set, the
     * official base applies.
     */
    searchBaseURL: Volatile<string | undefined>;
    /** Own Search API credential reference. With only {@link searchBaseURL} set, `DEEPSEEK_API_KEY` applies. */
    searchApiKeyEnv: Volatile<string | undefined>;
    /**
     * Own Fetch API base including its path prefix; `/fetch` is appended. With only {@link fetchApiKeyEnv} set, the
     * official base applies.
     */
    fetchBaseURL: Volatile<string | undefined>;
    /** Own Fetch API credential reference. With only {@link fetchBaseURL} set, `DEEPSEEK_API_KEY` applies. */
    fetchApiKeyEnv: Volatile<string | undefined>;
}
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    count: z<number, number, "volatile-defined">;
    searchRequestsPerSecond: z<number, number, "volatile-defined">;
    sendOriginalQuestion: z<boolean, boolean, "volatile-defined">;
    searchBaseURL: z<string, string, "volatile">;
    searchApiKeyEnv: z<string, string, "volatile">;
    fetchBaseURL: z<string, string, "volatile">;
    fetchApiKeyEnv: z<string, string, "volatile">;
}>>, Schemastery.ObjectT<NoInfer<{
    count: z<number, number, "volatile-defined">;
    searchRequestsPerSecond: z<number, number, "volatile-defined">;
    sendOriginalQuestion: z<boolean, boolean, "volatile-defined">;
    searchBaseURL: z<string, string, "volatile">;
    searchApiKeyEnv: z<string, string, "volatile">;
    fetchBaseURL: z<string, string, "volatile">;
    fetchApiKeyEnv: z<string, string, "volatile">;
}>>, "plain">;
/**
 * Register the Search API and Fetch API providers over one live settings section. Each operation reads one settings
 * snapshot and the route of the initiating Session's latest model request; each `ready()` call reads one settings
 * snapshot and the route of the model request being prepared. Both resolve the same plan.
 * @param ctx - plugin context owning both registrations.
 * @param config - live settings, read once per operation.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map