/**
 * Authentication and redirect-rejecting transport shared by the Search and
 * Fetch API providers in this package
 * ([rationale](../../../../.agents/notes/implemented/feature/2026-10-15-deepseek-search-fetch-api.md)).
 * @module @deepseek-ai/dsh-web-deepseek-api/transport
 */
import type { CredentialRef } from '@deepseek-ai/dsh-credentials';
import { WebError } from '@deepseek-ai/dsh-web';
/** Account token tried before the API key of an operation. */
interface DeepSeekWebAccountAuth {
    /** API base the token is sent to, including its path prefix. */
    baseURL: string;
    /** Resolve the token the account releases for a dispatch endpoint; undefined or empty selects the API key. */
    resolveToken: (endpoint: string) => Promise<string | undefined>;
    /** Invalidate the exact token rejected by HTTP 401; failures must not replace the request error. */
    rejectToken: (token: string) => Promise<void>;
}
/** Authentication values resolved once for an operation. */
export interface DeepSeekWebAuth {
    /** Account token sent to its own base when released; otherwise the API key is sent to the request's base. */
    account?: DeepSeekWebAccountAuth;
    /** Literal API key; takes precedence over the credential resolver. */
    apiKey?: string;
    /** Resolve the current API key without retaining it. */
    resolveApiKey?: () => Promise<string | undefined>;
    /** Credential reference named by missing-key diagnostics. */
    apiKeyEnv?: CredentialRef;
    /** Model-facing diagnostic thrown when no API key resolves; the generic one names {@link apiKeyEnv}. */
    missingKeyMessage?: string;
    /**
     * A mounted model route the operation depends on and whose settings do not resolve. The operation fails with
     * `WEB_PROVIDER_MISCONFIGURED` and {@link DeepSeekWebInvalidRoute.message} at the stage that would use the route,
     * before resolving its credential or sending anything.
     */
    invalidRoute?: DeepSeekWebInvalidRoute;
}
/** A model route whose settings do not resolve, and the stage of an operation that needs it. */
interface DeepSeekWebInvalidRoute {
    /** `account` fails before the account token is read; `api-key` fails where the API key would be resolved. */
    stage: 'account' | 'api-key';
    /** Model-facing diagnostic naming the route and its recoveries. */
    message: string;
}
/** User-owned endpoint settings named by dispatch failures. */
export interface DeepSeekWebGuidance {
    /** Capability whose endpoint failed. */
    subject: 'Search' | 'Fetch';
    /** Plugin configuration namespace. */
    plugin: string;
    /** Whether the endpoint is the capability's own base URL rather than one derived from a model route. */
    custom: boolean;
    /** Configuration field of the capability's own base URL. */
    baseURLField: string;
    /** Configuration field of the capability's own credential reference. */
    apiKeyEnvField: string;
}
/** One fully resolved web API request. */
interface DeepSeekWebRequest<T> {
    /** API base the API key is sent to, including its path prefix. */
    baseURL: string;
    /** Operation path appended to the base of the credential sent, such as `/search`. */
    path: string;
    /** JSON request body. */
    body: object;
    /** Protocol headers without credentials. */
    headers?: Readonly<Record<string, string>>;
    /** Additional API-key headers; not applied to account tokens. */
    apiKeyHeaders?: (key: string) => Readonly<Record<string, string>>;
    /** Validate and project the response. */
    decode: (payload: unknown) => T;
    /** Endpoint recovery settings. */
    guidance: DeepSeekWebGuidance;
    /** Record model input before dispatch; a throw prevents dispatch. */
    recordRequest?: (endpoint: string) => void;
    /** Wait for permission to send after credentials resolve; a rejection prevents dispatch. */
    waitToSend?: (signal?: AbortSignal) => Promise<void>;
}
/**
 * Check whether an authentication source exists; does not resolve credentials.
 * @param auth - Sources for the operation.
 * @returns Whether a literal key or resolver is present.
 */
export declare function hasDeepSeekWebCredential(auth: DeepSeekWebAuth): boolean;
/** Narrow a remote JSON object.
 * @param value - Untrusted JSON.
 * @returns Whether readable object fields exist.
 */
export declare function isRecord(value: unknown): value is Record<string, unknown>;
/** Report malformed upstream JSON without embedding response content.
 * @returns The stable provider error.
 */
export declare function invalidResponse(): WebError;
/** Dispatch one operation using a single settings and credential snapshot.
 * @param options - Authentication sources for this operation.
 * @param request - Resolved endpoint, JSON payload, and response decoder.
 * @param signal - Caller cancellation signal.
 * @returns The validated provider result.
 */
export declare function dispatchDeepSeekWeb<T>(options: DeepSeekWebAuth, request: DeepSeekWebRequest<T>, signal?: AbortSignal): Promise<T>;
/**
 * Build the provider's stable cancellation error while retaining the caller's reason.
 * @param signal - the aborted caller signal; its reason becomes the cause.
 * @param fallback - the cause when the signal has not aborted, such as a fetch `AbortError`.
 * @returns a `WEB_ABORTED` error.
 */
export declare function searchAborted(signal?: AbortSignal, fallback?: unknown): WebError;
export {};
//# sourceMappingURL=transport.d.ts.map