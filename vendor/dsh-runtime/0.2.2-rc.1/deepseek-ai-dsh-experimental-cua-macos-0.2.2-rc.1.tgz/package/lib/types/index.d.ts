import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import { CuaConfig } from '@deepseek-ai/dsh-cua';
import { type SourceSigning } from './native-build.ts';
export { GUIDANCE } from './guidance.ts';
/** Loader plugin identity. */
export declare const name = "experimental-cua-macos";
/** Services required by the shared CUA executor and the native launcher. */
export declare const inject: string[];
/** Native preparation, source-build signing, operation bounds, and profile-local application grants. */
export interface Config extends CuaConfig {
    /** Interval in milliseconds between permission and position checks while the native guide is open. */
    permissionPollIntervalMs: number;
    /**
     * Source-build signing: `ad-hoc` (default) binds grants to the code hash;
     * an object selects an existing certificate in an explicitly configured keychain.
     * Installed packages and `helperPath` keep their own signature.
     */
    sourceSigning: SourceSigning;
}
/** Validate shared operation bounds and macOS source signing before preparing the helper. */
export declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
    permissionPollIntervalMs: Schema<number, number, "defined">;
    sourceSigning: Schema<"ad-hoc" | ({
        identity?: string | null;
        keychain?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict), "ad-hoc" | Schemastery.ObjectT<NoInfer<{
        identity: Schema<string, string, "defined">;
        keychain: Schema<string, string, "defined">;
    }>>, "defined">;
    agentPreset: Schema<unknown, string | false>;
    allowedApps: Schema<unknown, (Omit<import("../../cua/src/application-types.ts").CuaApplicationGrant, "id"> & {
        id: string;
    })[]>;
    helperPath?: Schema<unknown, string | undefined>;
    buildTimeoutMs: Schema<unknown, number>;
    timeoutMs: Schema<unknown, number>;
    connectTimeoutMs: Schema<unknown, number>;
    screenshotTimeoutMs: Schema<unknown, number>;
    axTimeoutMs: Schema<unknown, number>;
    maxResponseBytes: Schema<unknown, number>;
    maxAppMatches: Schema<unknown, number>;
    maxClipboardBytes: Schema<unknown, number>;
    pasteReadTimeoutMs: Schema<unknown, number>;
    maxRequestBytes: Schema<unknown, number>;
    dragDurationMs: Schema<unknown, number>;
    maxClickHoldMs: Schema<unknown, number>;
    dragSteps: Schema<unknown, number>;
    textEventIntervalMs: Schema<unknown, number>;
    graceMs: Schema<unknown, number>;
    maxElements: Schema<unknown, number>;
    maxDepth: Schema<unknown, number>;
}>>, Schemastery.ObjectT<NoInfer<{
    permissionPollIntervalMs: Schema<number, number, "defined">;
    sourceSigning: Schema<"ad-hoc" | ({
        identity?: string | null;
        keychain?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict), "ad-hoc" | Schemastery.ObjectT<NoInfer<{
        identity: Schema<string, string, "defined">;
        keychain: Schema<string, string, "defined">;
    }>>, "defined">;
    agentPreset: Schema<unknown, string | false>;
    allowedApps: Schema<unknown, (Omit<import("../../cua/src/application-types.ts").CuaApplicationGrant, "id"> & {
        id: string;
    })[]>;
    helperPath?: Schema<unknown, string | undefined>;
    buildTimeoutMs: Schema<unknown, number>;
    timeoutMs: Schema<unknown, number>;
    connectTimeoutMs: Schema<unknown, number>;
    screenshotTimeoutMs: Schema<unknown, number>;
    axTimeoutMs: Schema<unknown, number>;
    maxResponseBytes: Schema<unknown, number>;
    maxAppMatches: Schema<unknown, number>;
    maxClipboardBytes: Schema<unknown, number>;
    pasteReadTimeoutMs: Schema<unknown, number>;
    maxRequestBytes: Schema<unknown, number>;
    dragDurationMs: Schema<unknown, number>;
    maxClickHoldMs: Schema<unknown, number>;
    dragSteps: Schema<unknown, number>;
    textEventIntervalMs: Schema<unknown, number>;
    graceMs: Schema<unknown, number>;
    maxElements: Schema<unknown, number>;
    maxDepth: Schema<unknown, number>;
}>>, "plain">;
/**
 * Mount logged native operations with separate Agent connections to the shared helper.
 * @param ctx - Host context with computer-use, subprocess and tool services.
 * @param config - Validated native preparation and operation bounds.
 * @returns Completion after native preparation and tool registration.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map