/** Choose between a side child card and a single-panel child page from layout-viewport space. */
/** Gap between the parent card and a side child card, matching `.submenu` in Menu.module.css. */
export declare const SUBMENU_GAP = 4;
/** Layout-viewport inset shared with every portalled Menu card. */
export declare const SUBMENU_MARGIN = 12;
/**
 * Report whether neither side of the parent card can hold the child card.
 * CSS anchors place the side card and flip it; this decision only selects the page layout.
 * @param parent - Parent card rectangle in client coordinates.
 * @param width - Natural child card width.
 * @param viewportWidth - Layout viewport width.
 * @returns true when the child must replace the parent page.
 */
export declare function submenuNeedsPage(parent: DOMRect, width: number, viewportWidth: number): boolean;
//# sourceMappingURL=menu-submenu-position.d.ts.map