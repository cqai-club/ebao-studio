/** Agent-owned mapping from observed screenshot pixels or integer ratios to native window points. */
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import type { CuaAppHandle, CuaOperation, CuaWindowInfo } from './types.ts';
/** Tracks only the current window geometry and last successfully prepared screenshot. */
export declare class CuaCoordinates {
    private readonly applications;
    /**
     * Invalidate screenshot mappings when a window closes or changes size.
     * @param appHandle - native application selection.
     * @param windows - freshly observed windows.
     * @param windowId - selected window for a scoped observation; omission means a complete application inventory.
     */
    observe(appHandle: CuaAppHandle, windows: readonly CuaWindowInfo[], windowId?: number): void;
    /**
     * Bind the exact image delivered to the model to its native window size.
     * @param appHandle - native application selection.
     * @param windowId - selected native window.
     * @param bounds - capture-time window size in points.
     * @param image - encoded model-request image dimensions.
     */
    screenshot(appHandle: CuaAppHandle, windowId: number, bounds: {
        width: number;
        height: number;
    }, image: {
        width: number;
        height: number;
    }): void;
    /**
     * Convert admitted coordinate arguments once, before native dispatch.
     * @param request - model request already checked by the operation schema.
     * @returns native parameters with Host-only coordinate options removed.
     */
    parameters(request: CuaOperation): Record<string, JsonValue>;
}
//# sourceMappingURL=coordinates.d.ts.map