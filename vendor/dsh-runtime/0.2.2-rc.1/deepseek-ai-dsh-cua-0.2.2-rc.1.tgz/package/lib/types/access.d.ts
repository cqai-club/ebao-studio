/** Browser controls for the provider's application decisions and native permission work. */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { ApplicationAccess, type AccessOptions } from './application-access.ts';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import { type NativeClientConfig, type NativeChannelFactory } from './native-client.ts';
import type { CuaApplicationId, CuaApplicationState, CuaSystemPermission, CuaSystemPermissionState } from './access-types.ts';
export { ApplicationAuthorizationResult } from './application-access.ts';
export type * from './access-types.ts';
interface ControlOptions extends AccessOptions {
    native: NativeClientConfig;
    createChannel: NativeChannelFactory;
    permissionParameters: (method: 'requestPermission' | 'openPermissionSettings', permission: CuaSystemPermission, locale: string) => Record<string, JsonValue>;
}
type Control = (method: string, params: Record<string, JsonValue>) => Promise<JsonValue>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Native permission controls and executor-owned application consent. */
        cuaAccess: CuaAccess;
    }
}
/** Browser controls for provider-owned native permission and application decisions. */
export declare class CuaAccess extends TypertRemoteService {
    private readonly policy;
    private readonly control;
    private readonly permissionParameters;
    /**
     * @param ctx Provider context.
     * @param policy Application decision owner.
     * @param control Serialized native permission dispatch.
     * @param permissionParameters Provider-owned native parameters for the selected action and Client language.
     */
    constructor(ctx: Context, policy: ApplicationAccess, control: Control, permissionParameters: ControlOptions['permissionParameters']);
    /** Read PTC execution state separately from native permission checks.
     * @returns Whether the shared runtime retains memory and has an editable profile entry.
     */
    ptcConfiguration(): {
        persistent: boolean;
        writable: boolean;
    };
    /** Persist in-memory PTC execution through the existing profile editor and Loader lifecycle.
     * @returns Completion after the shared runtime reload; already-persistent runtimes are left intact.
     */
    enablePersistentPtc(): Promise<void>;
    /**
     * Read fresh stored application decisions without issuing a native request.
     * @returns Saved grants, refused applications and durable-storage availability.
     */
    applications(): Promise<CuaApplicationState>;
    /**
     * Inspect system privileges independently of application decisions and icons.
     * @returns Fresh native preflight and launch metadata.
     */
    systemStatus(): Promise<CuaSystemPermissionState>;
    /**
     * Load presentation icons separately from application decisions.
     * @returns Optional native PNG icons keyed by executable path; applications without paths are skipped.
     */
    applicationIcons(): Promise<Record<string, string>>;
    /**
     * Request the selected system privilege through the native provider.
     * @param permission macOS privilege to request.
     * @param locale Current Client language for provider-owned permission UI.
     * @returns Current permission observations; requesting does not establish consent.
     */
    requestPermission(permission: CuaSystemPermission, locale: string): Promise<CuaSystemPermissionState>;
    /**
     * Open the macOS privacy pane selected by the user.
     * @param permission Corresponding system privilege.
     * @param locale Current Client language for provider-owned recovery instructions.
     * @returns Completion after macOS accepted the open request.
     */
    openSettings(permission: CuaSystemPermission, locale: string): Promise<void>;
    /**
     * Remove saved and session access and join affected operations.
     * @param id Application identity displayed on the permission page.
     * @returns Completion after persistence and cancellation; dispatched input cannot be undone.
     */
    revoke(id: CuaApplicationId): Promise<void>;
    /**
     * Clear this application's refusals across sessions so each session may ask for access again.
     * @param id Refused or revoked application displayed on the permission page.
     * @returns Completion after clearing refusals; no permission is granted and no action is replayed.
     */
    retryApproval(id: CuaApplicationId): Promise<void>;
}
/**
 * Install human-facing controls while keeping executor capabilities private to the provider.
 * @param ctx Provider context that owns decisions and operation lifetimes.
 * @param options Native transport and profile persistence.
 * @returns Consent selection, guarded dispatch, and task cleanup capabilities.
 */
export declare function installCuaAccess(ctx: Context, options: ControlOptions): Pick<ApplicationAccess, 'select' | 'run' | 'forget' | 'dispose'>;
//# sourceMappingURL=access.d.ts.map