/** Desktop text-input recognition for the SDK; command execution stays with the native registry. */
import type { CommandDescriptor } from '@deepseek-ai/dsh-commands/types';
/**
 * Recognize compact, explicit permission changes, plan, and goal by their definition identities.
 * Canonical and Chinese aliases follow the effective registered name; unrelated exact names remain prompts.
 * Other text remains a prompt.
 * @param text - original input; the caller preserves it on the ordinary-prompt path.
 * @param commands - exact receiving Agent's current command descriptors.
 * @returns the supported command line using its registered name and a native-compatible separator, otherwise undefined.
 */
export declare function queryCommand(text: string, commands: readonly CommandDescriptor[]): string | undefined;
//# sourceMappingURL=query-input.d.ts.map