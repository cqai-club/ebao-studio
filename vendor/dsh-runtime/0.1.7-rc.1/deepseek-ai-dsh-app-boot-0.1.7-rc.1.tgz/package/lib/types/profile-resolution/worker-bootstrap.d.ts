/** Install the inherited runtime resolution in one Harness-owned Worker. */
export {};
//# sourceMappingURL=worker-bootstrap.d.ts.map