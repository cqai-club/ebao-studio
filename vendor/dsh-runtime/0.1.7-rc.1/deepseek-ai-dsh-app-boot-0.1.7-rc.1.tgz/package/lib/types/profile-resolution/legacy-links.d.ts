/** Package directory canonicalization through the active runtime carrier's filesystem. */
/**
 * Resolve a directory through the active carrier's filesystem implementation.
 * @param path - directory path to canonicalize.
 * @returns the canonical directory path.
 */
export declare function realModuleDirectory(path: string): string;
//# sourceMappingURL=legacy-links.d.ts.map