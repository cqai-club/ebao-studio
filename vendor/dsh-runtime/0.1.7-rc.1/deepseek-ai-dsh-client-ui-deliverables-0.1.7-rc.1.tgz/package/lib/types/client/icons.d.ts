/**
 * Package-local glyph for the changed-files card until the shared icon set
 * carries it; its props already match the shared icon contract.
 */
import type { IconProps } from '@deepseek-ai/dsh-client-ui-primitives';
/** Angle brackets, the code mark the card's header tile shows. */
export declare const IconCodeBracketsOutline16: ({ size, className }: IconProps) => import("react").JSX.Element;
//# sourceMappingURL=icons.d.ts.map