"""Claude turn helpers."""
