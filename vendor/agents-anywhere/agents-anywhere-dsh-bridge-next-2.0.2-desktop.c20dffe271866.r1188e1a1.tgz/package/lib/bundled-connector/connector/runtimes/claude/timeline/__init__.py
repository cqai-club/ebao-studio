"""Claude timeline projection helpers."""
